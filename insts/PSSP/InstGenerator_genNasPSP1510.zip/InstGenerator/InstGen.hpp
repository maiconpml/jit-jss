/*
@author: Tadeu Knewitz Zubaran tkzubaran@gmail.com
*/

#pragma once


#include "InstGenSettings.hpp"
#include "italiano.hpp"

#include <vector>
#include <set>
#include <deque>

//#########################################################################################################################################################################################
class Arrow {
public:
	Arrow() {  }
	Arrow(unsigned from, unsigned to) {
		this->from = from;
		this->to = to;
	}
	~Arrow() {  }
	
	string toString() const {
		return unsigStr(from)+"->"+unsigStr(to);
	}
	
	bool operator==(const Arrow & arrow) const {
		return this->from == arrow.from   &&   this->to == arrow.to;
	}
	
	bool operator<(const Arrow & arrow) const {
		if(this->from < arrow.from) {
			return true;
		} else if(arrow.from < this->from) {
			return false;
		} else {
			if(this->to < arrow.to)
				return true;
			else
				return false;
		}
	}
	
	unsigned from;
	unsigned to;
};
//#########################################################################################################################################################################################
class InstGen {
public:
	InstGen(unsigned _nJobs, unsigned _nMachs) : nJobs(_nJobs), nMachs(_nMachs) {
		assert(nJobs <= MAX_ELEMENTS);
		jobCGs.resize(nJobs, ClosedGraph<MAX_ELEMENTS>(nMachs));
		jobSets.resize(nJobs);
	}
	InstGen() {  }
	~InstGen() {  }


	static void genAllPspFromTai(const string & inJspDirPath, const string & outPsiDirPath) {
		
		vector<unsigned> seeds = {013, 192, 277, 340, 441, 501, 678, 719};
		unsigned seedIndex = 0;
		string jspFilePath;
		string psiFilePath;

		//vector<InstGen> igv(800);
		//unsigned igvIndex=0;
		InstGen ig;

		for(unsigned taiIndex=1; taiIndex<=80; taiIndex++) {
			srand(seeds[seedIndex]);

			//cout << "taiIndex: " << taiIndex << endl;
			
			jspFilePath = inJspDirPath + "/ta" + (taiIndex<10 ? "0" : "") + unsigStr(taiIndex) + ".txt";

			//cout << "jspFilePath: " << jspFilePath << endl;

			for(unsigned rep=0; rep<10; rep++) {
				
				//cout << "\tigvIndex: " << igvIndex << endl;

				ig = taiJspToPsp(jspFilePath);

				psiFilePath = outPsiDirPath + "/pspTa"+  (taiIndex<10 ? "0" : "") + unsigStr(taiIndex) + "_" +unsigStr(rep) + ".psi";
				
				ig.printPsp(psiFilePath, true);

				//igv[igvIndex] = taiJspToPsp(jspFilePath);
				//assert(igvIndex == (taiIndex-1)*10+rep);
				//igvIndex++;
			}

			if(taiIndex%10 == 0)
				seedIndex++;
		}


		
	}


	//expects input instance to be in Tai format
	static InstGen taiJspToPsp(const string & jspPath) {
		unsigned nJobs;
		unsigned nMachs;
		vector<vector<unsigned>> readTimes;
		vector<vector<unsigned>> readOrder;

		unsigned precs;
		unsigned from;
		unsigned to;
		
		tie(nJobs, nMachs, readTimes, readOrder) = readTaiJspInfo(jspPath);

		vector<vector<unsigned>> psiTimes(nJobs, vector<unsigned>(nMachs, 0));
		
		InstGen ig(nJobs, nMachs);

	    for(unsigned a=0; a<nJobs; a++) {
			for(unsigned b=0; b<nMachs; b++) {
				psiTimes[a][readOrder[a][b]-1] = readTimes[a][b];
			}
		}

		ig.procTs = psiTimes;
		ig.nJobs = nJobs;
		ig.nMachs =nMachs;

		//inserting arrows
		for(unsigned j=0; j<nJobs; j++) {
			precs = rand() % nMachs+1;
			for(unsigned u=0; u<precs; u++) {
				do {
					from = rand() % nMachs;
					to = rand() % nMachs;
				} while (from == to);
				//cout << "insertting: " << from << "->" << to << endl;
				if( ! ig.jobCGs[j].path(to, from)) {
					ig.addArrow(j, Arrow(from, to));
				} else {
					assert( ! ig.jobCGs[j].path(from, to));
					ig.addArrow(j, Arrow(to, from));
				}
				assert( ! ig.jobCGs[j].hasCycle());
			}
		}

		return ig;
	}


	static void allAdmuStage(const string & jspDirPath, const string & nasStagesDir, const string & outDir, const string & jspFileOrderFilePath) {

		string bufStr;
		vector<string> jspFileNames;
		string jspFilePath;

		ifstream jspFileOrderInStream;

		jspFileOrderInStream.open(jspFileOrderFilePath);
		if( ! jspFileOrderInStream.is_open())
			throw errorText("Could not open file order file: "+jspFileOrderFilePath, "Parser.hpp", "Parser::sepAdmu()");

		for(unsigned u=0; u<40; u++) {
			jspFileOrderInStream >> bufStr;
			jspFileNames.push_back(bufStr);
		}


		for(unsigned admuI=1; admuI<=40; admuI++) {
			jspFilePath = jspDirPath + "/" + jspFileNames[admuI-1];
			admuToStage(jspFilePath, nasStagesDir, outDir,admuI);
		}

	}

	static void admuToStage(const string & jspFilePath, const string & nasStagesDir, const string & outDir, unsigned admuI) {

		//cout << "AAAA" << endl;

		ifstream jspInStream;

		string bufString;

		InstGen stageInst;

		unsigned nJobs;
		unsigned nMachs;

		unsigned fromOp;
		unsigned toOp;
		unsigned baseIndex;

		vector<vector<unsigned>> readTimes;
		vector<vector<unsigned>> readOrder;

		vector<vector<unsigned>> allStagePart;
		
		jspInStream.open(jspFilePath);
		if( ! jspInStream.is_open())
			throw errorText("Could not open Admu all instance file: "+jspFilePath, "Parser.hpp", "Parser::sepAdmu()");
		jspInStream >> nJobs;
		jspInStream >> nMachs;

		//cout << "\tnJobs: " << nJobs << " ; nMachs: " << nMachs << endl;
		
		readTimes.clear();
		readOrder.clear();
		readTimes.resize(nJobs, vector<unsigned>(nMachs));
		readOrder.resize(nJobs, vector<unsigned>(nMachs));

		//cout << "BBBB" << endl;

		for(unsigned j=0; j<nJobs; j++) {
			for(unsigned m=0; m<nMachs; m++) {
				jspInStream >> readOrder[j][m];
				jspInStream >> readTimes[j][m];
			}
		}

		/*cout << "\t\tREAD ORDER:\n";
		for(const vector<unsigned> v : readOrder) {
			for(const unsigned u : v) {
				cout << u << " ";
			}
			cout << endl;
			}*/

		//cout << "CCCC" << endl;

		allStagePart = readNasPart(nasStagesDir, nJobs, nMachs);
		/*
		cout << "\t\tSTAGE PART:\n";
		for(const vector<unsigned> v : allStagePart) {
			for(const unsigned u : v) {
				cout << u << " ";
			}
			cout << endl;
		}
		*/

		stageInst = InstGen();
		stageInst.procTs.resize(nJobs, vector<unsigned>(nMachs, 0));
		for(unsigned j=0; j<nJobs; j++) {
			for(unsigned u=0; u<nMachs; u++) {
				stageInst.procTs[j][readOrder[j][u]] = readTimes[j][u];
			}
		}
		stageInst.jobCGs.resize(nJobs, ClosedGraph<MAX_ELEMENTS>(nMachs));
		stageInst.jobSets.resize(nJobs);

		//cout << "DDDD" << endl;

		for(unsigned j=0; j<nJobs; j++) {
			baseIndex = 0;
			for(unsigned bailiff=0; bailiff<allStagePart[j].size()-1; bailiff++) {
				for(unsigned prevStageI=0; prevStageI<allStagePart[j][bailiff]; prevStageI++) {
					fromOp = readOrder[j][baseIndex + prevStageI];
					for(unsigned nextStageI=0; nextStageI<allStagePart[j][bailiff+1]; nextStageI++) {
						toOp = readOrder[j][baseIndex + allStagePart[j][bailiff]  + nextStageI];
						//cout << "from: " << fromOp << " ; toOp: " << toOp << endl;
						//getchar();
						stageInst.addArrow(j, Arrow(fromOp, toOp));
					}
				}
				baseIndex += allStagePart[j][bailiff];
			}
			//cout << endl;
		}

		//cout << "EEEE" << endl;

		//stageInst.printPsp("", false);
		//getchar();
		stageInst.printPsp(outDir+"/admuStage"+(string)(admuI<10 ? "0" : "")+unsigStr(admuI)+".psi", true);


		//cout << "FFFF" << endl;


		//getchar();
	}

	static void admuToStageOLD(const string &  inFilePath, const string & nasStagesDir, const string & outDir) {
		
		ifstream fromFile;
		string bufString;

		InstGen stageInst;

		unsigned nJobs;
		unsigned nMachs;

		unsigned fromOp;
		unsigned toOp;
		unsigned baseIndex;

		unsigned admuI = 1;

	    vector<vector<unsigned>> readTimes;
		vector<vector<unsigned>> readOrder;

		vector<vector<unsigned>> allStagePart;
		
		fromFile.open(inFilePath);
		if( ! fromFile.is_open())
			throw errorText("Could not open Admu all instance file: "+inFilePath, "Parser.hpp", "Parser::sepAdmu()");

		while(true) {
			for(unsigned i=0; i<12; i++) {
				fromFile >> bufString;
				//cout << bufString << endl;
				//getchar();
			}
			if(fromFile.eof())
				break;

			fromFile >> nJobs;
			fromFile >> nMachs;

			readTimes.clear();
			readOrder.clear();
			readTimes.resize(nJobs, vector<unsigned>(nMachs));
			readOrder.resize(nJobs, vector<unsigned>(nMachs));

		   for(unsigned j=0; j<nJobs; j++) {
				for(unsigned m=0; m<nMachs; m++) {
					fromFile >> readOrder[j][m];
					fromFile >> readTimes[j][m];
				}
			}

			allStagePart = readNasPart(nasStagesDir, nJobs, nMachs);

			stageInst = InstGen();
			stageInst.procTs.resize(nJobs, vector<unsigned>(nMachs, 0));
			for(unsigned j=0; j<nJobs; j++) {
				for(unsigned u=0; u<nMachs; u++) {
					stageInst.procTs[j][readOrder[j][u]] = readTimes[j][u];
				}
			}
			stageInst.jobCGs.resize(nJobs, ClosedGraph<MAX_ELEMENTS>(nMachs));
			stageInst.jobSets.resize(nJobs);

			/*for(unsigned j=0; j<nJobs; j++) {
				for(unsigned m=0; m<nMachs; m++) {
				    cout << readOrder[j][m] << "\t";
				}
				cout << endl;
			}
			cout << endl;
			for(unsigned j=0; j<nJobs; j++) {
				for(unsigned m=0; m<nMachs; m++) {
				    cout << readTimes[j][m] << "\t";
				}
				cout << endl;
			}
			getchar();*/

			for(unsigned j=0; j<nJobs; j++) {
				baseIndex = 0;
				for(unsigned bailiff=0; bailiff<allStagePart[j].size()-1; bailiff++) {
					for(unsigned prevStageI=0; prevStageI<allStagePart[j][bailiff]; prevStageI++) {
						fromOp = readOrder[j][baseIndex + prevStageI]-1;
						for(unsigned nextStageI=0; nextStageI<allStagePart[j][bailiff+1]; nextStageI++) {
							toOp = readOrder[j][baseIndex + allStagePart[j][bailiff]  + nextStageI]-1;
							//cout << "from: " << fromOp << " ; toOp: " << toOp << endl;
							//getchar();
							stageInst.addArrow(j, Arrow(fromOp, toOp));
						}
					}
					baseIndex += allStagePart[j][bailiff];
				}
				//cout << endl;
			}

			//stageInst.printPsp("", false);
			//getchar();
			stageInst.printPsp(outDir+"/admuStage"+(string)(admuI<10 ? "0" : "")+unsigStr(admuI)+".psi", true);
			admuI++;
		}
	}



	//spToActualStage(const string & jspTaiFormatPath, const string & nasStagesDir)
	//expects jsp to be in tai format
	static void spToActualStage(const string & inJspDir, const string & nasStagesDir, const string & outDir) {
		vector<string> fileNames =  filesInDir(inJspDir, ".txt");
		sort(fileNames.begin(), fileNames.end(), lexiOrder);

		InstGen ig;
		unsigned taIndex=0;

		for(const string & fileName : fileNames) {
			taIndex++;
			
			ig = jspToActualStage(inJspDir+"/"+fileName, nasStagesDir);
			ig.printPsp(outDir+"/actStage"+(string)(taIndex<10 ? "0" : "")+unsigStr(taIndex)+".psi", true);
		}
	}


	

	//expects files in Tai format
	static void batchJspToStage(const string & inDirPath, const string & outDirPath, unsigned reps) {

		vector<string> fileNames =  filesInDir(inDirPath, ".txt");
		sort(fileNames.begin(), fileNames.end(), lexiOrder);

	    InstGen ig;
		unsigned taIndex=0;
		
		for(const string & fileName : fileNames) {
			taIndex++;

			for(unsigned r=0; r<reps; r++) {
				ig = jspToStage(inDirPath+"/"+fileName);
				ig.printPsp(outDirPath+"/stageNas"+(string)(taIndex<10 ? "0" : "")+unsigStr(taIndex)+"_"+unsigStr(r)+".psi", true);
			}
		}
	} 



	//will add if awwor is not in set, does not check transitive closure
	void addArrow(unsigned jobIndex, const Arrow & a) {
		assert(jobIndex < jobCGs.size());
		assert( ! jobCGs[jobIndex].path(a.to, a.from));//forming cycle?
		
		unsigned oldSize = jobSets[jobIndex].size();
		jobSets[jobIndex].insert(a);
		if(oldSize < jobSets[jobIndex].size()) {
			if( ! jobCGs[jobIndex].path(a.from, a.to))
				jobCGs[jobIndex].add(a.from, a.to);
		} else {
			assert(jobCGs[jobIndex].path(a.from, a.to));
		}
	}
	
	
	
	void clear() {
		nJobs = 0;
		nMachs = 0;
		procTs.clear();
		jobCGs.clear();
		jobSets.clear();
	}



	void printPsp(const string & pspPath, bool toFile) const {
		assert(jobSets.size() > 0);
		assert(procTs.size() == jobSets.size());
		
		string str ="#START#\n\nTotalJobs: ";
		
		str.append(unsigStr(procTs.size()));
		str.append(" TotalMachines: ");
		str.append(unsigStr(procTs[0].size()));
		
		str.append("\nCosts:");
		for(const vector<unsigned> & v : procTs) {
			str.append("\n\t");
			for(unsigned u : v) {
				str.append(unsigStr(u)+" ");
			}
		}
		str.append("\n");
		
		for(const set<Arrow> & sa : jobSets) {
			str.append("\nJob: "+unsigStr(sa.size())+"\n");
			for(const Arrow & a : sa) {
				str.append("\n\t"+unsigStr(a.from)+" -> "+unsigStr(a.to));
			}
			str.append("\n");
		}
		
		if(toFile) {
			ofstream toFile;
			toFile.open(pspPath);
			if( ! toFile.is_open())
				throw errorText("Could not open file to write psp instance: "+pspPath, "Parser.hpp", "Parser::printPsp()");
			toFile << str; 
			toFile.close();
		} else {
			cout << str << endl;
		}
	}


	//@return nJobs, nMachs, times, orders
	static tuple<unsigned, unsigned, vector<vector<unsigned>>,vector<vector<unsigned>>> readTaiJspInfo(const string & filePath) {

		unsigned nJobs;
		unsigned nMachs;
		vector<vector<unsigned>> readTimes;
		vector<vector<unsigned>> readOrder;

		ifstream fromFile;
		string bufStr;
		
		fromFile.open(filePath);
		if( ! fromFile.is_open())
			throw errorText("Could not open partitioned Taillard's instance file: "+filePath, "Parser.hpp", "Parser::jspTaiFormatToPsi()");
			
		fromFile >> bufStr;
		assert(bufStr.compare("Jobs:")==0);
		fromFile >> nJobs;
		
		fromFile >> bufStr;
		assert(bufStr.compare("Machs:")==0);
		fromFile >> nMachs;
		
		assert(nJobs>0);
		assert(nJobs<10000);
		assert(nMachs>0);
		assert(nMachs<10000);
		
		fromFile >> bufStr;
		assert(bufStr.compare("Times:")==0);
		readTimes.resize(nJobs, vector<unsigned>(nMachs));
		for(unsigned j=0; j<nJobs; j++) {
			for(unsigned m=0; m<nMachs; m++) {
				fromFile >> readTimes[j][m];
			}
		}
		
		fromFile >> bufStr;
		assert(bufStr.compare("Order:")==0);
		readOrder.resize(nJobs, vector<unsigned>(nMachs));
		for(unsigned j=0; j<nJobs; j++) {
			for(unsigned m=0; m<nMachs; m++) {
				fromFile >> readOrder[j][m];
			}
		}
		fromFile.close();

		return  tuple<unsigned, unsigned, vector<vector<unsigned>>,vector<vector<unsigned>>> (nJobs, nMachs, readTimes, readOrder);
	}


	//JSP from Tai to Psi (stil JSP)
	static InstGen jspTaiFormatToPsi(const string & filePath) {
		unsigned nJobs;
		unsigned nMachs;
		vector<vector<unsigned>> readTimes;
		vector<vector<unsigned>> readOrder;
		
		tie(nJobs, nMachs, readTimes, readOrder) = readTaiJspInfo(filePath);
		
		InstGen gen(nJobs, nMachs);
		
		gen.procTs.resize(nJobs, vector<unsigned>(nMachs, 0));
		for(unsigned j=0; j<nJobs; j++) {
			for(unsigned u=0; u<nMachs; u++) {
				gen.procTs[j][readOrder[j][u]-1] = readTimes[j][u];
			}
		}
		//cout <<"\n!!!\n";
		//getchar();
		
		gen.jobCGs.clear(); 
		gen.jobSets.clear();
		
		gen.jobCGs.resize(nJobs, ClosedGraph<MAX_ELEMENTS>(nMachs));
		gen.jobSets.resize(nJobs);
		
		for(unsigned j=0; j<nJobs; j++) {
			for(unsigned u=0; u<nMachs-1; u++) {
				gen.addArrow(j, Arrow(readOrder[j][u]-1, readOrder[j][u+1]-1));
			}
		}

		
		return gen;
	}



	static vector<unsigned> genStagePartition(unsigned size) {
	
		unsigned nParts;
		vector<unsigned> bloat;

		nParts = 1+(rand() % size);
		bloat = vector<unsigned>(nParts,1);

		assert(nParts <= size);

		for(unsigned insertI=0; insertI<size-nParts; insertI++) {
			bloat[rand() % nParts]++;
		}

	    return bloat;
	}



	static InstGen jspToActualStage(const string & jspTaiFormatPath, const string & nasStagesDir) {
		
		InstGen stageInst;
		vector<vector<unsigned>> allStagePart;

		unsigned nJobs;
		unsigned nMachs;
		vector<vector<unsigned>> readTimes;
		vector<vector<unsigned>> readOrder;
		
		unsigned fromOp;
		unsigned toOp;
		unsigned baseIndex;
		
		tie(nJobs, nMachs, readTimes, readOrder) = readTaiJspInfo(jspTaiFormatPath);
		
		assert(nMachs > 0);
		assert(nJobs > 0);

		stageInst.procTs.resize(nJobs, vector<unsigned>(nMachs, 0));
		for(unsigned j=0; j<nJobs; j++) {
			for(unsigned u=0; u<nMachs; u++) {
				stageInst.procTs[j][readOrder[j][u]-1] = readTimes[j][u];
			}
		}
		stageInst.jobCGs.resize(nJobs, ClosedGraph<MAX_ELEMENTS>(nMachs));
		stageInst.jobSets.resize(nJobs);
		
		allStagePart = readNasPart(nasStagesDir, nJobs, nMachs);

		for(unsigned j=0; j<nJobs; j++) {
			baseIndex = 0;
		    for(unsigned bailiff=0; bailiff<allStagePart[j].size()-1; bailiff++) {
				for(unsigned prevStageI=0; prevStageI<allStagePart[j][bailiff]; prevStageI++) {
					fromOp = readOrder[j][baseIndex + prevStageI]-1;
					for(unsigned nextStageI=0; nextStageI<allStagePart[j][bailiff+1]; nextStageI++) {
						toOp = readOrder[j][baseIndex + allStagePart[j][bailiff]  + nextStageI]-1;
						//cout << "from: " << fromOp << " ; toOp: " << toOp << endl;
						stageInst.addArrow(j, Arrow(fromOp, toOp));
					}
				}
				baseIndex += allStagePart[j][bailiff];
			}
			//cout << endl;
		}

		return stageInst;
		
	}



	static vector<vector<unsigned>> readNasPart(const string & stageDir, unsigned nJobs, unsigned nMachs) {
		
		const string stageFilePath = stageDir+"/"+unsigStr(nJobs)+"_"+unsigStr(nMachs)+".txt";
		ifstream fromFile;
		vector<vector<unsigned>> nasPart(nJobs);
		unsigned partSize;

		fromFile.open(stageFilePath);
		if( ! fromFile.is_open())
			throw errorText("Could not open stage partition file: "+stageFilePath, "InstGen.hpp", "readNasPart");

		for(unsigned j=0; j<nJobs; j++) {
			fromFile >> partSize;
			assert(partSize != 0);
			nasPart[j].resize(partSize);
			for(unsigned p=0; p<partSize; p++) {
				fromFile >> nasPart[j][p];
			}
		}
		
		return nasPart;
	}



	static InstGen jspToStage(const string & filePath) {
		
		InstGen stageInst;
		vector<unsigned> stagePart;

		unsigned nJobs;
		unsigned nMachs;
		vector<vector<unsigned>> readTimes;
		vector<vector<unsigned>> readOrder;
		
		unsigned fromOp;
		unsigned toOp;
		unsigned baseIndex;
		
		tie(nJobs, nMachs, readTimes, readOrder) = readTaiJspInfo(filePath);
		
		assert(nMachs > 0);
		assert(nJobs > 0);

		stageInst.procTs.resize(nJobs, vector<unsigned>(nMachs, 0));
		for(unsigned j=0; j<nJobs; j++) {
			for(unsigned u=0; u<nMachs; u++) {
				stageInst.procTs[j][readOrder[j][u]-1] = readTimes[j][u];
			}
		}
		stageInst.jobCGs.resize(nJobs, ClosedGraph<MAX_ELEMENTS>(nMachs));
		stageInst.jobSets.resize(nJobs);
		
		for(unsigned j=0; j<nJobs; j++) {
			stagePart = genStagePartition(nMachs);

			//for(unsigned u : stagePart) cout << u << " ";
			//cout << endl << endl;
			
			baseIndex = 0;
			for(unsigned bailiff=0; bailiff<stagePart.size()-1; bailiff++) {
				for(unsigned prevStageI=0; prevStageI<stagePart[bailiff]; prevStageI++) {
					fromOp = readOrder[j][baseIndex + prevStageI]-1;
					for(unsigned nextStageI=0; nextStageI<stagePart[bailiff+1]; nextStageI++) {
						toOp = readOrder[j][baseIndex + stagePart[bailiff]  + nextStageI]-1;
						//cout << "from: " << fromOp << " ; toOp: " << toOp << endl;
						stageInst.addArrow(j, Arrow(fromOp, toOp));
					}
				}
				baseIndex += stagePart[bailiff];
			}
  
			//getchar();
		}
		
		return stageInst;
	}



	static InstGen fromRawPsspToMixed(const string & filePath, unsigned n0Size) {
		
		InstGen ig;

		ifstream fromFile;

		fromFile.open(filePath);
		if( ! fromFile.is_open())
			throw errorText("Could not open partitionedraw nonTaillard's instance file: "+filePath, "Parser.hpp", "fromRawPsspToMixed");

		fromFile >> ig.nJobs;
		ig.nJobs+=n0Size;
		fromFile >> ig.nMachs;

		vector<unsigned> order;
		unsigned aOrder;
		vector<unsigned> costs;
		unsigned aCost;

		ig.procTs.resize(ig.nJobs, vector<unsigned>(ig.nMachs));
		ig.jobCGs.resize(ig.nJobs, ClosedGraph<MAX_ELEMENTS>(ig.nMachs));
		ig.jobSets.resize(ig.nJobs);

		//Setting NJ
		for(unsigned j=0; j<ig.nJobs-n0Size; j++) {
			order.clear();
			costs.clear();
			for(unsigned m=0; m<ig.nMachs; m++) {
				fromFile >> aOrder;
				fromFile >> aCost;
				order.push_back(aOrder);
				costs.push_back(aCost);
			}

			for(unsigned index=0; index<ig.nMachs; index++) {
				ig.procTs[j][order[index]] = costs[index];
			}

			for(unsigned index=0; index<ig.nMachs-1; index++) {
				ig.addArrow(j, Arrow(order[index], order[index+1]));
			}
		}

		//Setting NO
		for(unsigned j=ig.nJobs-n0Size; j<ig.nJobs; j++) {
			for(unsigned index=0; index<ig.nMachs; index++) {
				ig.procTs[j][index] = rand()%98+1;//CONFIRM LIMITS
			}
		}

		fromFile.close();

		return ig;
	}
	
	

	unsigned nJobs;
	unsigned nMachs;

	vector<vector<unsigned>> procTs;
	
	vector<ClosedGraph<MAX_ELEMENTS>> jobCGs; 
	vector<set<Arrow>> jobSets;
};
//########################################################################################################################################################################################

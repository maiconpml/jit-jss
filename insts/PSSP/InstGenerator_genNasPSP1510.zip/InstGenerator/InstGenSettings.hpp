/*
@author: Tadeu Knewitz Zubaran tkzubaran@gmail.com
*/


#pragma once

#include "../GeneralSettings.hpp"

using namespace std;

//#####################################################
//###############         CONSTS        ###############
//#####################################################
#define MAX_ELEMENTS 200

//#####################################################
//###############      FLOW OPTIONS     ###############
//#####################################################
#define ITALIANO_WITH_COUNTER


//#####################################################
//##############     VERBOSE OPTIONS     ##############
//#####################################################
#define VERBOSE
void verbose(const string & str) {
#ifdef VERBOSE
	cout << str << endl;
#endif //VERBOSE
}

//#define STEP_BY_STEP
void stepByStep(const string & str) {
#ifdef STEP_BY_STEP
	cout << str << endl;
	getchar();
#endif //STEP_BY_STEP
}

#define ENABLE_LOG false



/*
@author: Tadeu Knewitz Zubaran tkzubaran@gmail.com
*/

#include "InstGenSettings.hpp"
//#include "Parser.hpp"
#include "InstGen.hpp"


int main(int argc, char *argv[]) {

	//srand(17);
	try{
		string inJspDirPath = "./Sources/TaiJspTaiFormat";
		string outPsiDirPath  = "./PSIinsts/PSP_NasiriStyle_151001";
	    InstGen::genAllPspFromTai(inJspDirPath, outPsiDirPath);

		

		//InstGen ig = InstGen::taiJspToPsp("./Sources/TaiJspTaiFormat/ta01.txt");
		//InstGen ig = InstGen::taiJspToPsp("./Sources/TaiJspTaiFormat/ta11.txt");
		//ig.printPsp("", false);


		/*const string jspFilePath = "./Sources/DemircJSP/rcmax_20_15_1.txt";
		const string nasStagesDir = "./Sources/NasStagePartitions";
		const string outDir = "./";
		unsigned admuI = 1;
		InstGen::admuToStage(jspFilePath, nasStagesDir, outDir, admuI);
		//getchar();*/
		/*
		const string jspDirPath = "./Sources/DemircJSP";
		const string nasStagesDir = "./Sources/NasStagePartitions";
		const string outDir = "./PSIinsts/NasStage1509_NASIRI_ORDER";
		const string jspFileOrderFilePath = "./Sources/DemircJSP/DemircInstOrder/instOrder.txt";
		InstGen::allAdmuStage(jspDirPath, nasStagesDir, outDir, jspFileOrderFilePath);
		*/
		//InstGen::admuToStage("./AdmuJsp/jcmax.txt", "./NasStagePartitions", "./AdmuJsp");

		//InstGen::spToActualStage("./TaiJspTaiFormatOnly50", "./NasStagePartitions", "./ActualStage");

		//makeNasActualStage(const string & jspTaiFormatPath, const string & nasStagesDir)
		//InstGen ig = InstGen::makeNasActualStage("./TaiJspTaiFormat/ta01.txt", "./NasStagePartitions");
		//ig.printPsp("", false);

		/*vector<unsigned> noSizeVec = {5, 10, 15, 20};
		vector<unsigned> instIndVec = {16, 24, 29, 36};
		InstGen ig;
		
		for(unsigned instInd : instIndVec) {
			for(unsigned noSize : noSizeVec) {
				for(unsigned rep=0; rep<10;rep++) {
					ig =  InstGen::fromRawPsspToMixed("./JSSPinstNonTai/la"+unsigStr(instInd)+"_raw.txt", noSize);
					ig.printPsp("./mixed_base"+unsigStr(instInd)+"_no"+unsigStr(noSize)+"_rep"+unsigStr(rep),true);
				}
			}
			}*/

		//InstGen ig = InstGen::fromRawPsspToMixed("./JSSPinstNonTai/la16_raw.txt", 5);
		//ig.printPsp("", false);

		//unsigned reps = 10;
		//InstGen::batchJspToStage("./TaiJspTaiFormat","./StageShopNasInsts", reps);

		//InstGen ig = InstGen::jspToStage("./TaiJspTaiFormat/ta01.txt");
		//ig.printPsp("", false);

		/*	
		InstGen ig;
		ig = InstGen::jspTaiFormatToPsi("./TaiJspTaiFormat/ta01.txt");

		//printPsp(const string & pspPath, bool toFile)		
		ig.printPsp("./TaiJspTaiFormat/ta01.txt",false);

		//vector<unsigned> part = InstGen::genStagePartition(10);
		//for(unsigned u : part) cout << u << " ";
		//cout << endl;

		//ig.setNasiriStage();
		*/
		
	} catch(const string e) {
		cout << e << endl;
	}
	return 0;
}

	

